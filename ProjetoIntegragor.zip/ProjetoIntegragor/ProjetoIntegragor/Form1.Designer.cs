﻿namespace ProjetoIntegragor
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn = new Button();
            btnlimpar = new Button();
            panel1 = new Panel();
            button8 = new Button();
            button7 = new Button();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            panel2 = new Panel();
            lblvelhap = new Label();
            lblvelha = new Label();
            lblpntoo = new Label();
            lblpontox = new Label();
            label2 = new Label();
            label1 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // btn
            // 
            btn.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            btn.Location = new Point(111, 23);
            btn.Name = "btn";
            btn.Size = new Size(75, 77);
            btn.TabIndex = 0;
            btn.UseVisualStyleBackColor = true;
            btn.Click += btn_Click;
            // 
            // btnlimpar
            // 
            btnlimpar.Location = new Point(124, 325);
            btnlimpar.Name = "btnlimpar";
            btnlimpar.Size = new Size(239, 46);
            btnlimpar.TabIndex = 9;
            btnlimpar.Text = "REINICIAR";
            btnlimpar.UseVisualStyleBackColor = true;
            btnlimpar.Click += btnlimpar_Click;
            // 
            // panel1
            // 
            panel1.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            panel1.BackgroundImage = Properties.Resources.JOGO_DA_VELHA;
            panel1.Controls.Add(button8);
            panel1.Controls.Add(button7);
            panel1.Controls.Add(button6);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(btn);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(480, 307);
            panel1.TabIndex = 10;
            panel1.Paint += panel1_Paint;
            // 
            // button8
            // 
            button8.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            button8.Location = new Point(273, 189);
            button8.Name = "button8";
            button8.Size = new Size(75, 77);
            button8.TabIndex = 8;
            button8.UseVisualStyleBackColor = true;
            button8.Click += btn_Click;
            // 
            // button7
            // 
            button7.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            button7.Location = new Point(192, 189);
            button7.Name = "button7";
            button7.Size = new Size(75, 77);
            button7.TabIndex = 7;
            button7.UseVisualStyleBackColor = true;
            button7.Click += btn_Click;
            // 
            // button6
            // 
            button6.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            button6.Location = new Point(111, 189);
            button6.Name = "button6";
            button6.Size = new Size(75, 77);
            button6.TabIndex = 6;
            button6.UseVisualStyleBackColor = true;
            button6.Click += btn_Click;
            // 
            // button5
            // 
            button5.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            button5.Location = new Point(273, 106);
            button5.Name = "button5";
            button5.Size = new Size(75, 77);
            button5.TabIndex = 5;
            button5.UseVisualStyleBackColor = true;
            button5.Click += btn_Click;
            // 
            // button4
            // 
            button4.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            button4.Location = new Point(192, 106);
            button4.Name = "button4";
            button4.Size = new Size(75, 77);
            button4.TabIndex = 4;
            button4.UseVisualStyleBackColor = true;
            button4.Click += btn_Click;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            button3.Location = new Point(111, 106);
            button3.Name = "button3";
            button3.Size = new Size(75, 77);
            button3.TabIndex = 3;
            button3.UseVisualStyleBackColor = true;
            button3.Click += btn_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            button2.Location = new Point(273, 23);
            button2.Name = "button2";
            button2.Size = new Size(75, 77);
            button2.TabIndex = 2;
            button2.UseVisualStyleBackColor = true;
            button2.Click += btn_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            button1.Location = new Point(192, 23);
            button1.Name = "button1";
            button1.Size = new Size(75, 77);
            button1.TabIndex = 1;
            button1.UseVisualStyleBackColor = true;
            button1.Click += btn_Click;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ButtonHighlight;
            panel2.Controls.Add(lblvelhap);
            panel2.Controls.Add(lblvelha);
            panel2.Controls.Add(lblpntoo);
            panel2.Controls.Add(lblpontox);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(12, 377);
            panel2.Name = "panel2";
            panel2.Size = new Size(480, 92);
            panel2.TabIndex = 11;
            // 
            // lblvelhap
            // 
            lblvelhap.AutoSize = true;
            lblvelhap.Location = new Point(218, 61);
            lblvelhap.Name = "lblvelhap";
            lblvelhap.Size = new Size(13, 15);
            lblvelhap.TabIndex = 5;
            lblvelhap.Text = "0";
            // 
            // lblvelha
            // 
            lblvelha.AutoSize = true;
            lblvelha.Location = new Point(203, 26);
            lblvelha.Name = "lblvelha";
            lblvelha.Size = new Size(43, 15);
            lblvelha.TabIndex = 4;
            lblvelha.Text = "VELHA";
            // 
            // lblpntoo
            // 
            lblpntoo.AutoSize = true;
            lblpntoo.Location = new Point(396, 61);
            lblpntoo.Name = "lblpntoo";
            lblpntoo.Size = new Size(13, 15);
            lblpntoo.TabIndex = 3;
            lblpntoo.Text = "0";
            // 
            // lblpontox
            // 
            lblpontox.AutoSize = true;
            lblpontox.Location = new Point(43, 61);
            lblpontox.Name = "lblpontox";
            lblpontox.Size = new Size(13, 15);
            lblpontox.TabIndex = 2;
            lblpontox.Text = "0";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(373, 26);
            label2.Name = "label2";
            label2.Size = new Size(64, 15);
            label2.TabIndex = 1;
            label2.Text = "PONTOS O";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(27, 26);
            label1.Name = "label1";
            label1.Size = new Size(62, 15);
            label1.TabIndex = 0;
            label1.Text = "PONTOS X";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            BackgroundImage = Properties.Resources.JOGO_DA_VELHA;
            ClientSize = new Size(504, 481);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(btnlimpar);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button btn;
        private Button btnlimpar;
        private Panel panel1;
        private Panel panel2;
        private Label label2;
        private Label label1;
        private Label lblpntoo;
        private Label lblpontox;
        private Button button8;
        private Button button7;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private Label lblvelhap;
        private Label lblvelha;
    }
}
