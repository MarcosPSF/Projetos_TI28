﻿namespace ProjetoIntegragor
{
    partial class Frmcadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtlogin = new TextBox();
            txtsenha = new TextBox();
            btncadastro = new Button();
            SuspendLayout();
            // 
            // txtlogin
            // 
            txtlogin.ForeColor = Color.Black;
            txtlogin.Location = new Point(188, 388);
            txtlogin.Name = "txtlogin";
            txtlogin.PlaceholderText = "LOGIN";
            txtlogin.Size = new Size(100, 23);
            txtlogin.TabIndex = 0;
            // 
            // txtsenha
            // 
            txtsenha.Location = new Point(188, 417);
            txtsenha.Name = "txtsenha";
            txtsenha.PasswordChar = '*';
            txtsenha.PlaceholderText = "SENHA";
            txtsenha.Size = new Size(100, 23);
            txtsenha.TabIndex = 1;
            txtsenha.TextChanged += txtsenha_TextChanged;
            // 
            // btncadastro
            // 
            btncadastro.Location = new Point(188, 446);
            btncadastro.Name = "btncadastro";
            btncadastro.Size = new Size(100, 23);
            btncadastro.TabIndex = 2;
            btncadastro.Tag = "";
            btncadastro.Text = "CADASTE-SE";
            btncadastro.UseVisualStyleBackColor = true;
            btncadastro.Click += btncadastro_Click;
            // 
            // Frmcadastro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.JOGO_DA_VELHA;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(504, 481);
            Controls.Add(btncadastro);
            Controls.Add(txtsenha);
            Controls.Add(txtlogin);
            DoubleBuffered = true;
            Name = "Frmcadastro";
            Text = "Frmcadastro";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtlogin;
        private TextBox txtsenha;
        private Button btncadastro;
    }
}