﻿using System;
using System.Data.SQLite;
using System.IO;

namespace ProjetoIntegragor
{
    public class DatabaseConfig
    {
        // Caminho do arquivo do banco de dados SQLite
        private const string dbFile = "ProjetoIntegragorDB.sqlite";

        // Método para configurar e inicializar o banco de dados
        public static void InitializeDatabase()
        {
            // Verifica se o arquivo do banco de dados já existe
            if (!File.Exists(dbFile))
            {
                // Cria o banco de dados SQLite
                SQLiteConnection.CreateFile(dbFile);
                Console.WriteLine("Banco de dados criado.");

                using (var connection = new SQLiteConnection($"Data Source={dbFile};Version=3;"))
                {
                    connection.Open();

                    // Cria a tabela Usuarios
                    string createUsuariosTable = @"
                        CREATE TABLE Usuarios (
                            Id INTEGER PRIMARY KEY AUTOINCREMENT,
                            Username TEXT NOT NULL,
                            Password TEXT NOT NULL
                        );";

                    var cmdUsuarios = new SQLiteCommand(createUsuariosTable, connection);
                    cmdUsuarios.ExecuteNonQuery();
                    Console.WriteLine("Tabela Usuarios criada.");

                    
                }
            }
            else
            {
                Console.WriteLine("Banco de dados já existe.");
            }
        }
    }
}
