﻿using ProjetoIntegragor;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace ProjetoIntegragor
{
    public partial class FrmLogin : Form
    {
        private const string connectionString = "Data Source=ProjetoIntegragorDB.sqlite;Version=3;";

        public FrmLogin()
        {
            InitializeComponent();
        }

       

        private void btncadastro_Click(object sender, EventArgs e)
        {
            Frmcadastro cli = new Frmcadastro();
            cli.ShowDialog();
        }

        private void btnentra_Click(object sender, EventArgs e)
        {
            {
                string username = txtlogin.Text;
                string password = txtsenha.Text;

                using (var connection = new SQLiteConnection(connectionString))
                {
                    string query = "SELECT COUNT(1) FROM Usuarios WHERE Username = @Username AND Password = @Password";
                    var cmd = new SQLiteCommand(query, connection);

                    // Define os parâmetros da consulta
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);

                    try
                    {
                        connection.Open();
                        int count = Convert.ToInt32(cmd.ExecuteScalar());

                        if (count == 1)
                        {
                            MessageBox.Show("Login bem-sucedido!");
                            this.Hide();
                            Form1 form1 = new Form1();
                            form1.Show();
                        }
                        else
                        {
                            MessageBox.Show("Usuário ou senha incorretos.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message);
                    }
                }
            }

        }
    }
}

