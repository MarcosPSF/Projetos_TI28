﻿namespace ProjetoIntegragor
{
    partial class FrmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmLogin));
            btnentra = new Button();
            btncadastro = new Button();
            txtlogin = new TextBox();
            txtsenha = new TextBox();
            l = new Label();
            SuspendLayout();
            // 
            // btnentra
            // 
            btnentra.Location = new Point(126, 443);
            btnentra.Name = "btnentra";
            btnentra.Size = new Size(100, 26);
            btnentra.TabIndex = 0;
            btnentra.Text = "ENTRA";
            btnentra.UseVisualStyleBackColor = true;
            btnentra.Click += btnentra_Click;
            // 
            // btncadastro
            // 
            btncadastro.Location = new Point(261, 443);
            btncadastro.Name = "btncadastro";
            btncadastro.Size = new Size(100, 26);
            btncadastro.TabIndex = 1;
            btncadastro.Text = "CADASTRO";
            btncadastro.UseVisualStyleBackColor = true;
            btncadastro.Click += btncadastro_Click;
            // 
            // txtlogin
            // 
            txtlogin.Location = new Point(126, 414);
            txtlogin.Name = "txtlogin";
            txtlogin.PlaceholderText = "LOGIN";
            txtlogin.Size = new Size(100, 23);
            txtlogin.TabIndex = 2;
            // 
            // txtsenha
            // 
            txtsenha.Location = new Point(261, 414);
            txtsenha.Name = "txtsenha";
            txtsenha.PasswordChar = '*';
            txtsenha.PlaceholderText = "SENHA";
            txtsenha.Size = new Size(100, 23);
            txtsenha.TabIndex = 3;
            // 
            // l
            // 
            l.AutoSize = true;
            l.Location = new Point(299, 160);
            l.Name = "l";
            l.Size = new Size(0, 15);
            l.TabIndex = 5;
            // 
            // FrmLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(504, 481);
            Controls.Add(l);
            Controls.Add(txtsenha);
            Controls.Add(txtlogin);
            Controls.Add(btncadastro);
            Controls.Add(btnentra);
            DoubleBuffered = true;
            Name = "FrmLogin";
            Text = "FrmLogin";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnentra;
        private Button btncadastro;
        private TextBox txtlogin;
        private TextBox txtsenha;
        private Label l;
    }
}