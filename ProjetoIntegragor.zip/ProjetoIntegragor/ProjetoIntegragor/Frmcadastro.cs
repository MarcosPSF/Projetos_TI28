﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoIntegragor
{
    public partial class Frmcadastro : Form
    {
        private const string connectionString = "Data Source=ProjetoIntegragorDB.sqlite;Version=3;";
        public Frmcadastro()
        {
            InitializeComponent();
        }

        private void btncadastro_Click(object sender, EventArgs e)
        {
            // Obtém o nome de usuário e senha digitados pelo usuário
            string username = txtlogin.Text;
            string password = txtsenha.Text;

            // Verifica se os campos estão preenchidos
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Por favor, preencha todos os campos.");
                return;
            }

            // Conexão com o banco de dados SQLite
            using (var connection = new SQLiteConnection(connectionString))
            {
                // Consulta SQL para inserir o novo usuário
                string query = "INSERT INTO Usuarios (Username, Password) VALUES (@Username, @Password)";
                var cmd = new SQLiteCommand(query, connection);

                // Define os parâmetros da consulta
                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@Password", password); // Para maior segurança, use um hash de senha no lugar de armazenar a senha em texto puro

                try
                {
                    // Abre a conexão com o banco de dados
                    connection.Open();

                    // Executa a consulta para inserir o novo usuário
                    cmd.ExecuteNonQuery();

                    // Exibe uma mensagem de sucesso e limpa os campos
                    MessageBox.Show("Usuário cadastrado com sucesso!");
                    txtlogin.Clear();
                    txtsenha.Clear();
                }
                catch (SQLiteException ex) when (ex.ErrorCode == (int)SQLiteErrorCode.Constraint)
                {
                    // Captura a exceção caso o nome de usuário já exista
                    MessageBox.Show("Este nome de usuário já está em uso.");
                }
                catch (Exception ex)
                {
                    // Captura qualquer outro erro
                    MessageBox.Show("Erro ao cadastrar usuário: " + ex.Message);
                }
            }
        }

        private void txtsenha_TextChanged(object sender, EventArgs e)
        {

        }
    }
}


